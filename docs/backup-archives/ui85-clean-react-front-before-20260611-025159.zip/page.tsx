﻿/**
 * COLLECTIUM FILE HEADER
 *
 * Overskrift:
 * Collectium UI85 Front Page
 *
 * Definering / formal:
 * Frontsiden for app.collectium.no. Denne bruker Collectium UI85 React-template
 * direkte i app/page.tsx. UI85 skal ikke ligge som preview/canvas-route.
 *
 * Bruksomrade:
 * - /
 *
 * Berorte sider / routes:
 * - /
 *
 * Berorte DB-brytere / feature_keys:
 * - landing.view
 * - template.ui85.front.view
 *
 * Berorte API-ruter:
 * - Ingen direkte i denne filen. Fronten viser React-template. Datakoblede
 *   komponenter skal senere hente via API/backend.
 *
 * Berorte tabeller / views:
 * - Ingen direkte.
 *
 * Dataretning:
 * MariaDB/Neon -> API/backend -> Next.js -> React -> UI
 *
 * Logging:
 * log_category: template
 * log_action: ui85.front.view
 *
 * Versjon:
 * UI85-FRONT-V1 / CHANGE-UI85-2026-06-11-FRONT-0001
 *
 * Endringsregel:
 * Dette erstatter preview/canvas-bruk med React-front.
 */

import { CollectiumUi85Template } from "./components/templates/ui85/CollectiumUi85Template";
import { CollectiumUi85ObjectPreview } from "./components/templates/ui85/CollectiumUi85ObjectPreview";

export default function CollectiumFrontPage() {
  return (
    <CollectiumUi85Template skin="finans">
      <CollectiumUi85ObjectPreview />
    </CollectiumUi85Template>
  );
}
