﻿"use client";

/**
 * COLLECTIUM FILE HEADER
 *
 * Overskrift:
 * Collectium Theme Menu
 *
 * Definering / formal:
 * Tema-knapp for eksisterende global toppmeny. Bygger paa UI 8.5 HTML-retning:
 * fire skin-valg, dot-farger, lokal data-skin-kontroll og ingen ny shell.
 *
 * Bruksomrade:
 * - Eksisterende global topbar/header
 *
 * Berorte sider / routes:
 * - Global topbar
 *
 * Berorte DB-brytere / feature_keys:
 * - template.theme.select
 *
 * Berorte API-ruter:
 * - Ingen. Dette er lokal template-/skin-kontroll.
 *
 * Berorte tabeller / views:
 * - Ingen.
 *
 * Dataretning:
 * Lokal UI-kontroll -> data-skin paa html/body -> global CSS/tokens
 *
 * Logging:
 * log_category: template
 * log_action: theme.select
 *
 * Versjon:
 * THEME-MENU-FROM-HTML-V1 / CHANGE-2026-06-11-THEME-0002
 */

import { useEffect, useRef, useState } from "react";
import styles from "./CollectiumThemeMenu.module.css";

type SkinKey = "collectium" | "samler" | "museum" | "finans";

const SKINS: Array<{
  key: SkinKey;
  label: string;
}> = [
  { key: "collectium", label: "Collectium" },
  { key: "samler", label: "Samler" },
  { key: "museum", label: "Museum" },
  { key: "finans", label: "Finans" },
];

const STORAGE_KEY = "ct-ui85-preview-skin";

function normalizeSkin(value: string | null): SkinKey {
  if (value === "collectium" || value === "samler" || value === "museum" || value === "finans") {
    return value;
  }

  return "collectium";
}

function applySkin(skin: SkinKey) {
  if (typeof document === "undefined") {
    return;
  }

  document.documentElement.dataset.skin = skin;
  document.body.dataset.skin = skin;
  document.documentElement.setAttribute("data-ct-skin", skin);
  document.body.setAttribute("data-ct-skin", skin);

  try {
    window.localStorage.setItem(STORAGE_KEY, skin);
    window.localStorage.setItem("collectium-active-skin", skin);
  } catch {
    // LocalStorage kan vaere blokkert. data-skin er fortsatt satt.
  }

  window.dispatchEvent(new CustomEvent("collectium:skin-change", { detail: { skin } }));
}

export function CollectiumThemeMenu() {
  const [activeSkin, setActiveSkin] = useState<SkinKey>("collectium");
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let initial = "collectium";

    try {
      initial =
        window.localStorage.getItem(STORAGE_KEY) ??
        window.localStorage.getItem("collectium-active-skin") ??
        "";
    } catch {
      initial = "";
    }

    if (!initial) {
      initial =
        document.documentElement.dataset.skin ??
        document.body.dataset.skin ??
        document.documentElement.getAttribute("data-ct-skin") ??
        document.body.getAttribute("data-ct-skin") ??
        "collectium";
    }

    const nextSkin = normalizeSkin(initial);
    setActiveSkin(nextSkin);
    applySkin(nextSkin);
  }, []);

  useEffect(() => {
    function onPointerDown(event: PointerEvent) {
      if (!rootRef.current) {
        return;
      }

      if (!rootRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
      }
    }

    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);

    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, []);

  function selectSkin(skin: SkinKey) {
    setActiveSkin(skin);
    applySkin(skin);
    setOpen(false);
  }

  return (
    <div className={styles.themeMenu} ref={rootRef}>
      <button
        type="button"
        className={styles.trigger}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        Tema
      </button>

      {open ? (
        <nav className={styles.menu} aria-label="Skinvelger">
          <strong>Skinn</strong>

          {SKINS.map((skin) => (
            <button
              key={skin.key}
              type="button"
              className={styles.skinButton}
              data-active={activeSkin === skin.key ? "true" : "false"}
              aria-pressed={activeSkin === skin.key}
              onClick={() => selectSkin(skin.key)}
            >
              <span className={styles.dot} data-skin-dot={skin.key} />
              {skin.label}
            </button>
          ))}
        </nav>
      ) : null}
    </div>
  );
}
